default_app_config = 'field_app.apps.FieldAppConfig'  # 👈 Ongeza hii
