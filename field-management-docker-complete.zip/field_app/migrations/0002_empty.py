from django.db import migrations

class Migration(migrations.Migration):
    dependencies = [
        ('field_app', '0001_initial'),
    ]

    operations = [
        # No operations - empty migration
    ]
